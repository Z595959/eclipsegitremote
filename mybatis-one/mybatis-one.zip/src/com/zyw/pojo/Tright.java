package com.zyw.pojo;

public class Tright {
	private int trightid;
	private String tright_name;
	
	public int getTrightid() {
		return trightid;
	}
	public void setTrightid(int trightid) {
		this.trightid = trightid;
	}
	public String getTright_name() {
		return tright_name;
	}
	public void setTright_name(String tright_name) {
		this.tright_name = tright_name;
	}
	
	
}
